import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { setAlertMsg } from "../../store/common/commonActions";
import SVLS_API from "../../svls-api";
import USABET_API from "../../api-services/usabet-api";
import {
  IonButton,
  IonInput,
  IonLabel,
  IonRow,
  IonCol,
  IonCard,
  IonCardContent,
} from "@ionic/react";
import "./TwoFactorAuthTab.scss";
import { TextField } from "@material-ui/core";

interface TwoFactorAuthTabProps {
  userDetails: any;
  langData: any;
}

const TwoFactorAuthTab: React.FC<TwoFactorAuthTabProps> = ({
  userDetails,
  langData,
}) => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [qrCodeLink, setQrCodeLink] = useState<string>("");
  const [otp, setOtp] = useState("");
  const [password, setPassword] = useState("");
  const [setupPassword, setSetupPassword] = useState("");
  const [showSetup, setShowSetup] = useState(false);
  const [is2FAEnabled, setIs2FAEnabled] = useState(false);
  const [telegramConnection, setTelegramConnection] = useState<{
    bot: string;
    connection_id: string;
    message: string;
  } | null>(null);

  useEffect(() => {
    // Check if 2FA is already enabled for the user using is2faVerified field
    const is2FAEnabled =
      userDetails?.is2faVerified ||
      userDetails?.twoFactorEnabled ||
      userDetails?.is2FAEnabled;

    setIs2FAEnabled(!!is2FAEnabled);
  }, [userDetails]);

  const fetch2FALink = async () => {
    try {
      setIsLoading(true);
      const response = await SVLS_API.post("/account/two-factor-auth/", null, {
        headers: {
          Authorization: sessionStorage.getItem("jwt_token"),
        },
      });

      if (response.data) {
        setQrCodeLink(response.data);
        setShowSetup(true);
      }
    } catch (error) {
      dispatch(
        setAlertMsg({
          type: "error",
          message:
            langData?.["2fa_link_error"] || "Failed to get 2FA setup link",
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const fetchTelegramConnectionId = async () => {
    if (!setupPassword.trim()) {
      dispatch(
        setAlertMsg({
          type: "error",
          message:
            langData?.["please_enter_password_txt"] ||
            "Please enter your login password to continue",
        })
      );
      return;
    }
    try {
      setIsLoading(true);
      setTelegramConnection(null);
      const response = await USABET_API.post(
        "/telegram/generateTelegramConnectionId",
        { password: setupPassword.trim() }
      );
      const resData = response?.data;
      if (resData?.status === true && resData?.data) {
        const bot = resData.data.bot || "@Tenexch9_bot";
        setTelegramConnection({
          bot: bot.startsWith("@") ? bot : `@${bot}`,
          connection_id: resData.data.connection_id || "",
          message: resData.data.message || "",
        });
        setShowSetup(true);
        dispatch(
          setAlertMsg({
            type: "success",
            message: resData?.msg || "Connection ID generated successfully",
          })
        );
      } else {
        dispatch(
          setAlertMsg({
            type: "error",
            message: resData?.msg || "Failed to generate connection ID",
          })
        );
      }
    } catch (err: any) {
      dispatch(
        setAlertMsg({
          type: "error",
          message:
            err?.response?.data?.msg ||
            err?.response?.data?.message ||
            "Failed to generate connection ID",
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleEnable2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim() || !password.trim()) {
      dispatch(
        setAlertMsg({
          type: "error",
          message:
            langData?.["2fa_required_fields"] ||
            "Please enter OTP and password",
        })
      );
      return;
    }

    try {
      const response = await SVLS_API.put(
        "/account/two-factor-auth/",
        {
          otp: otp,
          password: password,
          status: true,
          loginType: "PASS",
        },
        {
          headers: {
            Authorization: sessionStorage.getItem("jwt_token"),
          },
        }
      );

      if (response.status === 200) {
        dispatch(
          setAlertMsg({
            type: "success",
            message:
              langData?.["2fa_enabled_success"] || "2FA enabled successfully!",
          })
        );
        setIs2FAEnabled(true);
        setShowSetup(false);
        setOtp("");
        setPassword("");
        setQrCodeLink("");
      }
    } catch (error) {
      dispatch(
        setAlertMsg({
          type: "error",
          message: error?.response?.data?.message || "Failed to enable 2FA",
        })
      );
    }
  };

  const handleDisable2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim() || !password.trim()) {
      dispatch(
        setAlertMsg({
          type: "error",
          message:
            langData?.["2fa_required_fields"] ||
            "Please enter OTP and password",
        })
      );
      return;
    }

    try {
      const response = await SVLS_API.put(
        "/account/two-factor-auth/",
        {
          otp: otp,
          password: password,
          status: false,
          loginType: "PASS",
        },
        {
          headers: {
            Authorization: sessionStorage.getItem("jwt_token"),
          },
        }
      );

      if (response.status === 200) {
        dispatch(
          setAlertMsg({
            type: "success",
            message:
              langData?.["2fa_disabled_success"] ||
              "2FA disabled successfully!",
          })
        );
        setIs2FAEnabled(false);
        setOtp("");
        setPassword("");
      }
    } catch (error) {
      dispatch(
        setAlertMsg({
          type: "error",
          message: langData?.["2fa_disable_error"] || "Failed to disable 2FA",
        })
      );
    }
  };

  const formatOTPInput = (value: string) => {
    // Remove non-numeric characters and limit to 6 digits
    const numericValue = value.replace(/\D/g, "").slice(0, 6);
    return numericValue;
  };

  const handleOTPChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatOTPInput(e.target.value);
    setOtp(formattedValue);
  };

  if (is2FAEnabled) {
    return (
      <div className="two-factor-auth-container">
        <IonCard style={{ margin: "0" }}>
          <IonCardContent>
            <div className="two-factor-status">
              <div
                style={{
                  textOverflow: "nowrap",
                  fontSize: "18px",
                  fontWeight: "bold",
                }}
              >
                {langData?.["2fa_disabled_title"] ||
                  "Two-Factor Authentication"}
              </div>
              <p>
                {langData?.["2fa_manage_description"] ||
                  "Manage your two-factor authentication settings"}
              </p>

              <div className="status-indicator enabled">
                <span className="status-icon">✓</span>
                <span>
                  {langData?.["2fa_enabled_status"] || "2FA is enabled"}
                </span>
              </div>

              <form onSubmit={handleDisable2FA} className="two-factor-form">
                <div style={{ fontWeight: "bold" }}>
                  {langData?.["2fa_disable_title"] ||
                    "Disable Two-Factor Authentication"}
                </div>
                <p>
                  {langData?.["2fa_disable_description"] ||
                    "To disable 2FA, enter your current password and the 6-digit code from your authenticator app."}
                </p>

                <div
                  style={{
                    width: "100%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      gap: "6px",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <div
                      className="text-nowrap"
                      style={{
                        width: "40%",
                      }}
                    >
                      {langData?.["2fa_otp_label"] || "Authentication Code"}
                    </div>
                    <TextField
                      type="text"
                      value={otp}
                      onChange={handleOTPChange}
                      placeholder="123456"
                      inputProps={{ maxLength: 6 }}
                      className="otp-input"
                      style={{
                        textAlign: "center",
                        fontSize: "18px",
                        letterSpacing: "2px",
                        fontFamily: "monospace",
                        width: "100%",
                      }}
                    />
                  </div>
                  <div
                    style={{
                      display: "flex",
                      gap: "6px",
                      justifyContent: "space-between",
                      alignItems: "center",
                      background:'#fff'
                    }}
                  >
                    <div
                      className="text-nowrap"
                      style={{
                        width: "40%",
                      }}
                    >
                      {langData?.["password_label"] || "Current Password"}
                    </div>

                    <TextField
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={
                        langData?.["password_placeholder"] ||
                        "Enter your current password"
                      }
                      className="telegram-password-input"
                      InputProps={{
                        style: {
                          color: "var(--ion-text-color, #333)",
                          textAlign: "center",
                          fontSize: "18px",
                          letterSpacing: "2px",
                          fontFamily: "monospace",
                        },
                      }}
                      inputProps={{ style: { width: "100%" } }}
                    />
                  </div>
                </div>

                <IonButton
                  type="submit"
                  color="danger"
                  expand="block"
                  className="disable-button"
                >
                  {langData?.["2fa_disable_button"] || "Disable 2FA"}
                </IonButton>
              </form>
            </div>
          </IonCardContent>
        </IonCard>
      </div>
    );
  }

  return (
    <div className="two-factor-auth-container">
      <IonCard>
        <IonCardContent>
          <div className="two-factor-setup">
            <div
              style={{
                textOverflow: "nowrap",
                fontSize: "18px",
                fontWeight: "bold",
              }}
            >
              {langData?.["2fa_setup_title"] ||
                "Two-Factor Authentication Setup"}
            </div>
            <p>
              {langData?.["2fa_setup_description"] ||
                "Secure your account with an additional layer of protection"}
            </p>

            {!showSetup ? (
              <div className="setup-instructions telegram-setup">
                <div className="setup-icon">
                  <span>📱</span>
                </div>
                <h4>
                  {langData?.["telegram_2fa_title"] ||
                    "Telegram 2-Step Verification"}
                </h4>
                <p>
                  {langData?.["please_enter_password_txt"] ||
                    "Please enter your login password to continue"}
                </p>

                <div className="telegram-password-section">
                  <TextField
                    type="password"
                    value={setupPassword}
                    onChange={(e) => setSetupPassword(e.target.value)}
                    placeholder={
                      langData?.["password_placeholder"] ||
                      "Enter your password"
                    }
                    className="telegram-password-input"
                    fullWidth
                    variant="outlined"
                    margin="normal"
                    InputProps={{
                      style: { color: "#fff" },
                      inputProps: {
                        "aria-label": "Password",
                        style: {
                          color: "#fff",
                          WebkitTextFillColor: "#fff",
                        },
                      },
                    }}
                  />
                  <IonButton
                    onClick={fetchTelegramConnectionId}
                    disabled={isLoading}
                    color="primary"
                    expand="block"
                    className="setup-button get-connection-btn"
                  >
                    {isLoading
                      ? langData?.["loading"] || "Loading..."
                      : langData?.["get_connection_id_txt"] || "Get Connection ID"}
                  </IonButton>
                </div>
              </div>
            ) : telegramConnection ? (
              <div className="telegram-instructions telegram-instructions-v2">
                <div className="telegram-instructions-card-v2">
                  <h4 className="telegram-main-heading">
                    {langData?.["telegram_instructions_heading"] ||
                      "Please follow below instructions for the telegram 2-step verification"}
                  </h4>

                  <div className="telegram-step-section">
                    <p className="telegram-step-text">
                      {langData?.["telegram_step1_prefix"] || "Find"}{" "}
                      <span className="telegram-bot-link">
                        {telegramConnection.bot}
                      </span>{" "}
                      {langData?.["telegram_step1_mid"] || "in your telegram and type"}{" "}
                      <span className="telegram-command-badge">/start</span>{" "}
                      {langData?.["telegram_step1_suffix"] || "command. Bot will respond you."}
                    </p>
                  </div>

                  <div className="telegram-step-section">
                    <p className="telegram-step-text">
                      {langData?.["telegram_step2_prefix"] || "After this type"}{" "}
                      <span className="telegram-command-badge">
                        /connect {telegramConnection.connection_id}
                      </span>{" "}
                      {langData?.["telegram_step2_suffix"] || "and send it to BOT."}
                    </p>
                  </div>

                  <div className="telegram-step-section">
                    <p className="telegram-step-text telegram-result-text">
                      {langData?.["telegram_step3_result"] ||
                        "Now your telegram account will be linked with your website account and 2-Step verification will be enabled."}
                    </p>
                  </div>

                  <div className="telegram-divider" />

                  <h4 className="telegram-hindi-heading">
                    {langData?.["telegram_instructions_heading_hi"] ||
                      "कृपया टेलीग्राम 2-Step verification के लिए नीचे दिए गए निर्देशों का पालन करें:"}
                  </h4>

                  <div className="telegram-step-section">
                    <p className="telegram-step-text">
                      {langData?.["telegram_step1_hi_prefix"] || "अपने टेलीग्राम में"}{" "}
                      <span className="telegram-bot-link">
                        {telegramConnection.bot}
                      </span>{" "}
                      {langData?.["telegram_step1_hi_mid"] || "खोजें और कमांड"}{" "}
                      <span className="telegram-command-badge">/start</span>{" "}
                      {langData?.["telegram_step1_hi_suffix"] || "टाइप करें. BOT आपको जवाब देगा."}
                    </p>
                  </div>

                  <div className="telegram-step-section">
                    <p className="telegram-step-text">
                      {langData?.["telegram_step2_hi_prefix"] || "इसके बाद"}{" "}
                      <span className="telegram-command-badge">
                        /connect {telegramConnection.connection_id}
                      </span>{" "}
                      {langData?.["telegram_step2_hi_suffix"] || "टाइप करें और इसे BOT पर भेजें."}
                    </p>
                  </div>

                  <div className="telegram-step-section">
                    <p className="telegram-step-text telegram-result-text">
                      {langData?.["telegram_step3_hi_result"] ||
                        "अब आपका टेलीग्राम account आपके वेबसाइट account से जुड़ जाएगा और 2-Step verification चालू हो जाएगा."}
                    </p>
                  </div>

                  <p className="telegram-expiry-note">
                    {langData?.["connection_expires_txt"] ||
                      "Connection ID expires in 60 seconds."}
                  </p>
                </div>
                <IonButton
                  color="medium"
                  expand="block"
                  className="back-button"
                  onClick={() => {
                    setShowSetup(false);
                    setTelegramConnection(null);
                    setSetupPassword("");
                  }}
                >
                  {langData?.["back"] || "Back"}
                </IonButton>
              </div>
            ) : null}
          </div>
        </IonCardContent>
      </IonCard>
    </div>
  );
};

export default TwoFactorAuthTab;
